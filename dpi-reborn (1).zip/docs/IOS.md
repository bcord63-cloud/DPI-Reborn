# DPI Reborn para iOS: estado e plano

**Estado: não existe versão para iOS.** Não foi possível criar nem compilar um app de iPhone neste ambiente: ele exige um Mac com Xcode, conta de desenvolvedor Apple e testes em aparelho. O app Android não pode ser convertido; a versão iOS será um projeto independente em Swift/SwiftUI. O aviso "Em breve" no app Android é só um aviso.

## O que já pode ser compartilhado (sem reescrever)

- **`catalog/catalog.json`**: lista de apps de PS4 (nome, categoria, repositório, regex do arquivo, compatibilidade). Independente de plataforma.
- **`assets/changelog.json`**: histórico de versões em JSON.
- **Verificação das fontes**: API de releases do GitHub (versão, data, tamanho, SHA-256), descrita em `CatalogRepository.kt`. É HTTP + JSON e se reimplementa em Swift com `URLSession`.
- **Protocolos de envio ao PS4** (README): API do Remote Package Installer (porta 12800), payload do GoldHEN, manifesto JSON e servidor HTTP com Range. Também reimplementáveis em Swift.
- **Protocolo FTP do módulo YouTube**: comandos em `FtpClient.kt` e regras de merge do `plugins.ini` em `YtAdblockViewModel.kt`.

## O que é específico do Android

Interface (`ui/`), DownloadManager, Storage Access Framework, serviço em primeiro plano e permissões.

## Pontos a avaliar antes de começar o iOS

- App Transport Security (HTTP sem TLS na rede local exige exceção declarada).
- Servidor HTTP em segundo plano no iPhone é limitado pelo sistema.
- Regras da App Store para apps que instalam conteúdo em consoles com jailbreak (a distribuição pode ter de ser fora da App Store).
- Favoritos e sincronização entre aparelhos exigiriam um backend próprio, que não existe hoje.

Nada disso foi analisado a fundo ou testado.
