# Catálogo de apps de PS4

O app lê `catalog/catalog.json` (do repositório > cópia salva > embutido em `assets/catalog.json`) e verifica cada item ao vivo. Editar o arquivo no GitHub cadastra, remove (`"removed": true`) ou recategoriza apps sem gerar novo APK.

Campos: `id`, `name`, `description`, `category` (Emuladores, Homebrew, Mídia, Ferramentas, Outros), `platforms` (só PS4), `developer`, `sourceUrl` (https), `github` (dono/repo), `assetRegex`, `license`, `compat`, `emulates`, `added`, `removed`, `special`.

## O que foi verificado ao montar o catálogo inicial

Lido nas páginas dos projetos: Dolphin PS4 (iHaiDeeZ, GPL-2.0, publica `DolphinPS4-vXX.pkg`), EmuFive (blue0x1, emulador de PS5 que roda via Linux no PS4, release sem PKG), GoldHEN (v2.3 marcada como Latest), GoldHEN Plugins Repository (GPL-3.0, formato do `plugins.ini`) e Apollo Save Tool (GPL-3.0). Remote Package Installer, PS4-4PT, FPKGi e PKG-Zone aparecem em buscas, mas suas releases/arquivos não foram lidos: o app confere ao vivo e mostra "indisponível" se não achar.

## Não encontrado (não listado)

EmuSuNi, PlayStation Vue como homebrew e um Kick para PS4 não apareceram em fontes verificáveis. Twitch e o YouTube oficiais são distribuídos pela PlayStation Store, não em PKG; o catálogo traz só o módulo do plugin do YouTube.

## Limites

- API do GitHub sem login: 60 consultas por hora. Descobrir usa a busca (limite menor).
- Sem API pública conhecida do PKG-Zone: só link para a página.
- "Descobrir" mostra resultados não verificados; nada é baixado deles automaticamente.
