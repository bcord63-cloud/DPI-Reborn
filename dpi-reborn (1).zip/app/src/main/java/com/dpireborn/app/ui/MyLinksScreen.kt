package com.dpireborn.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dpireborn.app.apps.AppPkg
import com.dpireborn.app.apps.AppsViewModel
import com.dpireborn.app.apps.UrlRules
import com.dpireborn.app.ui.theme.DangerRed
import com.dpireborn.app.ui.theme.OutlineDim
import com.dpireborn.app.ui.theme.SuccessGreen
import com.dpireborn.app.ui.theme.SurfaceDark
import com.dpireborn.app.ui.theme.TextSecondary
import com.dpireborn.app.ui.theme.WarnAmber

/** Apps (só PKG): você cadastra o link de um .pkg, o celular baixa e envia ao PS4 pelo mesmo mecanismo da Biblioteca. */
@Composable
fun MyLinksScreen(avm: AppsViewModel) {
    val apps by avm.apps.collectAsStateWithLifecycle()
    val speeds by avm.speeds.collectAsStateWithLifecycle()
    var showAdd by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
            Text(
                "PKG por link: baixa no celular e envia ao PS4",
                style = MaterialTheme.typography.bodySmall, color = TextSecondary, modifier = Modifier.weight(1f),
            )
            FilledTonalButton(onClick = { showAdd = true }) {
                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Text("  Adicionar")
            }
        }
        if (apps.isEmpty()) {
            Box(modifier = Modifier.weight(1f)) {
                EmptyState(
                    icon = Icons.Filled.Apps,
                    title = "Nenhum app cadastrado",
                    text = "Toque em Adicionar e cole o link direto (https) de um arquivo .pkg, por exemplo o link de um arquivo " +
                        "numa Release do GitHub. O download é feito pelo celular e não tem limite de 30 MB.",
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 12.dp),
            ) {
                items(apps, key = { it.id }) { p -> AppPkgCard(p, speeds[p.id] ?: 0L, avm) }
            }
        }
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = WarnAmber.copy(alpha = 0.08f)),
            border = BorderStroke(1.dp, WarnAmber.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        ) {
            Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.Top) {
                Icon(Icons.Filled.Warning, contentDescription = null, tint = WarnAmber, modifier = Modifier.size(18.dp))
                Text(
                    "  Use só links de fontes em que você confia e de arquivos que pode usar. O app baixa só quando você toca " +
                        "em Baixar, confere se o arquivo é mesmo um PKG e nunca instala nada sozinho.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }

    if (showAdd) AddAppDialog(avm) { showAdd = false }
}

@Composable
fun AppPkgCard(p: AppPkg, speed: Long, avm: AppsViewModel) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        border = BorderStroke(1.dp, OutlineDim),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(p.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(UrlRules.host(p.url), style = MaterialTheme.typography.bodySmall, color = TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = { avm.remove(p.id, false) }) { Icon(Icons.Filled.Delete, contentDescription = "Remover da lista") }
            }
            when (p.status) {
                "RUNNING" -> {
                    Spacer(Modifier.height(6.dp))
                    if (p.size > 0) LinearProgressIndicator(progress = { p.progress }, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text(
                        "${formatSize(p.received)} de ${if (p.size > 0) formatSize(p.size) else "?"} • ${formatSpeed(speed)} • ${p.detail}" +
                            if (p.sendAfter) " • envia ao PS4 no fim" else "",
                        style = MaterialTheme.typography.bodySmall, color = TextSecondary, modifier = Modifier.padding(top = 6.dp),
                    )
                    OutlinedButton(onClick = { avm.cancel(p.id) }, modifier = Modifier.padding(top = 6.dp)) { Text("Cancelar") }
                }
                "DONE" -> {
                    Text("Baixado • ${formatSize(p.size)}", color = SuccessGreen, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                        Button(onClick = { avm.sendNow(p.id) }) {
                            Icon(Icons.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("  Enviar ao PS4")
                        }
                        TextButton(onClick = { avm.remove(p.id, true) }) { Text("Apagar arquivo") }
                    }
                }
                else -> {
                    if (p.status == "FAILED" || p.detail.isNotEmpty()) {
                        Text(p.detail, color = if (p.status == "FAILED") DangerRed else TextSecondary, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                        Button(onClick = { avm.start(p.id, true) }) {
                            Icon(Icons.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("  Baixar e enviar")
                        }
                        OutlinedButton(onClick = { avm.start(p.id, false) }) {
                            Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("  Só baixar")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddAppDialog(avm: AppsViewModel, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Adicionar PKG por link") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Nome") }, colors = fieldColors(), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = url, onValueChange = { url = it }, label = { Text("Link do .pkg (https://…)") },
                    colors = fieldColors(), modifier = Modifier.fillMaxWidth(),
                )
                error?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(onClick = {
                val e = avm.add(name, url)
                if (e == null) onDismiss() else error = e
            }) { Text("Adicionar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}
