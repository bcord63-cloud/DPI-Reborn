package com.dpireborn.app.catalog

/** Entrada do catálogo de PS4, lida do catalog.json (online, cópia salva ou embutido). */
data class CatalogApp(
    val id: String,
    val name: String,
    val description: String,
    val category: String,
    val platforms: List<String>,
    val developer: String,
    val sourceUrl: String,
    val github: String?,
    val assetRegex: String?,
    val license: String?,
    val added: Long,
    val removed: Boolean,
    val compat: String?,
    val emulates: String?,
    val special: String?,
) {
    val coverUrl: String? get() = github?.let { "https://opengraph.githubassets.com/1/$it" }
    val iconUrl: String? get() = github?.let { "https://github.com/${it.substringBefore('/')}.png?size=96" }
}

/** Dados lidos ao vivo da fonte (release do GitHub). */
data class ResolvedRelease(
    val version: String,
    val publishedAt: Long,
    val publisher: String?,
    val assetName: String?,
    val size: Long,
    val downloadUrl: String?,
    val sha256: String?,
    val prerelease: Boolean,
    val releaseUrl: String?,
) {
    val isPkg: Boolean get() = assetName?.endsWith(".pkg", ignoreCase = true) == true
}

enum class SourceStatus { DOWNLOAD, LINK, UNCHECKED, UNAVAILABLE }

data class CatalogEntry(
    val app: CatalogApp,
    val release: ResolvedRelease?,
    val status: SourceStatus,
    val note: String?,
    val checkedAt: Long,
    val previousVersion: String? = null,
) {
    /** Baixar dentro do app só vale para PKG com arquivo verificado. */
    val canDownloadPkg: Boolean get() = status == SourceStatus.DOWNLOAD && release?.isPkg == true && release.downloadUrl != null
    val hasUpdate: Boolean get() = previousVersion != null && release != null && previousVersion != release.version
}

/** Resultado de busca no GitHub: candidato NÃO verificado. */
data class Candidate(
    val fullName: String,
    val description: String,
    val stars: Int,
    val updatedAt: Long,
    val url: String,
)

object UrlGuard {
    private val ipLike = Regex("^[0-9.]+$")

    /** Só HTTPS com nome de domínio (sem IP, localhost ou usuário/senha na URL). */
    fun isSafeHttps(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val u = try {
            java.net.URI(url)
        } catch (e: Exception) {
            return false
        }
        if (!"https".equals(u.scheme, ignoreCase = true) || u.userInfo != null) return false
        val h = u.host ?: return false
        if (h == "localhost" || h.endsWith(".local") || h.contains(":") || ipLike.matches(h)) return false
        return h.contains('.')
    }

    fun host(url: String): String = try {
        java.net.URI(url).host ?: url
    } catch (e: Exception) {
        url
    }
}
