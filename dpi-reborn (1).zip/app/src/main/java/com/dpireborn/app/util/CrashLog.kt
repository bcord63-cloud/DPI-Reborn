package com.dpireborn.app.util

import android.app.Application
import android.os.Build
import android.util.Log
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Registro de erros em arquivo. Sem computador não dá para ver o logcat, então qualquer fechamento inesperado
 * (exceção não tratada) fica salvo aqui e aparece em Configurações → Diagnóstico, onde dá para copiar o texto.
 */
object CrashLog {
    private const val NAME = "diagnostico.log"
    private const val MAX = 60_000
    private var file: File? = null
    private var versionLine = ""

    fun install(app: Application) {
        file = File(app.filesDir, NAME)
        versionLine = try {
            val v = app.packageManager.getPackageInfo(app.packageName, 0).versionName
            "DPI Reborn $v • Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) • ${Build.MANUFACTURER} ${Build.MODEL}"
        } catch (e: Exception) {
            "DPI Reborn • Android ${Build.VERSION.SDK_INT}"
        }
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                write("FECHAMENTO INESPERADO na thread ${t.name}", e)
            } catch (ignored: Throwable) {
                // não pode falhar de novo dentro do tratador
            }
            previous?.uncaughtException(t, e)
        }
    }

    fun log(tag: String, msg: String, e: Throwable? = null) {
        Log.w("DPIReborn", "$tag: $msg", e)
        try {
            write("$tag: $msg", e)
        } catch (ignored: Throwable) {
            // diagnóstico nunca deve derrubar o app
        }
    }

    @Synchronized
    private fun write(title: String, e: Throwable?) {
        val f = file ?: return
        val sw = StringWriter()
        e?.let { it.printStackTrace(PrintWriter(sw)) }
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val entry = "[$stamp] $title\n$versionLine\n$sw\n"
        val old = if (f.exists()) f.readText() else ""
        val all = entry + old
        f.writeText(if (all.length > MAX) all.substring(0, MAX) else all)
    }

    fun read(): String = try {
        file?.takeIf { it.exists() }?.readText() ?: ""
    } catch (e: Exception) {
        ""
    }

    fun clear() {
        try {
            file?.delete()
        } catch (e: Exception) {
            // ignora
        }
    }
}
