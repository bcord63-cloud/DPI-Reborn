package com.dpireborn.app.apps

import android.app.Application
import android.app.DownloadManager
import android.net.Uri
import android.os.Environment
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Um PKG que o usuário cadastrou por link. status: IDLE, RUNNING, DONE ou FAILED. */
data class AppPkg(
    val id: String,
    val name: String,
    val url: String,
    val status: String = "IDLE",
    val dmId: Long = 0L,
    val path: String = "",
    val received: Long = 0L,
    val size: Long = 0L,
    val detail: String = "",
    val sendAfter: Boolean = false,
    val sha256: String? = null,
) {
    val progress: Float
        get() = if (size <= 0L) 0f else (received.toDouble() / size.toDouble()).coerceIn(0.0, 1.0).toFloat()
}

object UrlRules {
    private val ipLike = Regex("^[0-9.]+$")

    /** Só HTTPS com nome de domínio (sem IP, localhost ou usuário/senha na URL). */
    fun isSafeHttps(url: String): Boolean {
        val u = try {
            java.net.URI(url.trim())
        } catch (e: Exception) {
            return false
        }
        if (!"https".equals(u.scheme, ignoreCase = true) || u.userInfo != null) return false
        val h = u.host ?: return false
        if (h == "localhost" || h.endsWith(".local") || h.contains(":") || ipLike.matches(h)) return false
        return h.contains('.')
    }

    fun host(url: String): String = try {
        java.net.URI(url).host ?: url
    } catch (e: Exception) {
        url
    }

    /** Nome do arquivo no fim do caminho da URL (sem a query). Vazio se não terminar em .pkg. */
    fun pkgFileName(url: String): String {
        val last = try {
            java.net.URI(url.trim()).path?.substringAfterLast('/') ?: ""
        } catch (e: Exception) {
            ""
        }
        val clean = Uri.decode(last).replace(Regex("[^A-Za-z0-9._-]"), "_")
        return if (clean.endsWith(".pkg", ignoreCase = true) && clean.length > 4) clean else ""
    }
}

class AppsViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val dm = ctx.getSystemService(android.content.Context.DOWNLOAD_SERVICE) as DownloadManager
    private val file = File(ctx.filesDir, "apps_pkg.json")

    val apps = MutableStateFlow(load())
    val speeds = MutableStateFlow<Map<String, Long>>(emptyMap())
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    /** Caminhos de PKG baixados que devem ser enviados ao PS4 (quem escuta chama o envio existente). */
    val sendRequests = MutableSharedFlow<String>(extraBufferCapacity = 8)

    init {
        apps.value.filter { it.status == "RUNNING" }.forEach { watch(it.id) }
    }

    private fun say(m: String) {
        messages.tryEmit(m)
    }

    private fun load(): List<AppPkg> = try {
        val a = if (file.exists()) JSONArray(file.readText()) else JSONArray()
        val out = ArrayList<AppPkg>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out.add(
                AppPkg(
                    o.getString("id"), o.getString("name"), o.getString("url"), o.optString("status", "IDLE"),
                    o.optLong("dmId"), o.optString("path"), o.optLong("received"), o.optLong("size"),
                    o.optString("detail"), o.optBoolean("sendAfter"),
                    if (o.isNull("sha256")) null else o.optString("sha256").ifBlank { null },
                )
            )
        }
        out
    } catch (e: Exception) {
        emptyList()
    }

    private fun persist() {
        try {
            val a = JSONArray()
            for (p in apps.value) {
                a.put(
                    JSONObject().put("id", p.id).put("name", p.name).put("url", p.url).put("status", p.status)
                        .put("dmId", p.dmId).put("path", p.path).put("received", p.received).put("size", p.size)
                        .put("detail", p.detail).put("sendAfter", p.sendAfter).put("sha256", p.sha256 ?: JSONObject.NULL)
                )
            }
            val tmp = File(file.parentFile, file.name + ".tmp")
            tmp.writeText(a.toString())
            if (!tmp.renameTo(file)) file.writeText(a.toString())
        } catch (e: Exception) {
            // regrava na próxima alteração
        }
    }

    private fun upd(id: String, f: (AppPkg) -> AppPkg) {
        apps.update { l -> l.map { if (it.id == id) f(it) else it } }
    }

    /** Retorna uma mensagem de erro, ou null se cadastrou. */
    fun add(name: String, url: String, sha256: String? = null): String? {
        val u = url.trim()
        if (name.isBlank()) return "Dê um nome ao app"
        if (!UrlRules.isSafeHttps(u)) return "O link precisa começar com https:// e ter um endereço de site válido"
        if (UrlRules.pkgFileName(u).isEmpty()) return "O link precisa apontar para um arquivo .pkg"
        if (apps.value.any { it.url == u }) return "Este link já está na lista"
        apps.update { it + AppPkg(UUID.randomUUID().toString(), name.trim(), u, sha256 = sha256) }
        persist()
        return null
    }

    /** Usado pelo catálogo: cadastra (se ainda não existe) e inicia o download, com SHA-256 quando a fonte publicou. */
    fun addAndStart(name: String, url: String, sha256: String?, send: Boolean) {
        val existing = apps.value.firstOrNull { it.url == url }
        if (existing == null) {
            val err = add(name, url, sha256)
            if (err != null) {
                say(err)
                return
            }
        }
        val id = apps.value.firstOrNull { it.url == url }?.id ?: return
        start(id, send)
    }

    fun remove(id: String, deleteFile: Boolean) {
        val p = apps.value.firstOrNull { it.id == id } ?: return
        if (p.status == "RUNNING") cancel(id)
        if (deleteFile && p.path.isNotEmpty()) File(p.path).takeIf { it.isFile }?.delete()
        apps.update { l -> l.filter { it.id != id } }
        persist()
    }

    /** Baixa pelo gerenciador de downloads do Android (sem limite de tamanho). Com [send], envia ao PS4 no fim. */
    fun start(id: String, send: Boolean) {
        val p = apps.value.firstOrNull { it.id == id } ?: return
        if (p.status == "RUNNING") return
        val base = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
        val name = UrlRules.pkgFileName(p.url)
        if (base == null || name.isEmpty() || !UrlRules.isSafeHttps(p.url)) {
            say("Não foi possível iniciar: link ou armazenamento inválido")
            return
        }
        val dest = File(base, "DPI-Reborn/$name")
        try {
            dest.parentFile?.mkdirs()
            if (dest.exists()) dest.delete()
            val req = DownloadManager.Request(Uri.parse(p.url))
                .setTitle(p.name)
                .setDescription("DPI Reborn")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(ctx, Environment.DIRECTORY_DOWNLOADS, "DPI-Reborn/$name")
                .addRequestHeader("User-Agent", "DPI-Reborn (Android)")
            val dmId = dm.enqueue(req)
            upd(id) { it.copy(status = "RUNNING", dmId = dmId, path = dest.absolutePath, received = 0L, size = 0L, detail = "Na fila", sendAfter = send) }
            persist()
            watch(id)
        } catch (e: Exception) {
            say("Não foi possível iniciar o download: ${e.message ?: "erro"}")
        }
    }

    fun cancel(id: String) {
        val p = apps.value.firstOrNull { it.id == id } ?: return
        try {
            dm.remove(p.dmId)
        } catch (e: Exception) {
            // já removido
        }
        if (p.path.isNotEmpty()) File(p.path).takeIf { it.isFile }?.delete()
        upd(id) { it.copy(status = "IDLE", received = 0L, detail = "Download cancelado") }
        speeds.update { it - id }
        persist()
    }

    /** Envia ao PS4 um PKG já baixado. */
    fun sendNow(id: String) {
        val p = apps.value.firstOrNull { it.id == id } ?: return
        if (p.status == "DONE" && File(p.path).isFile) sendRequests.tryEmit(p.path) else say("Arquivo não encontrado: baixe de novo")
    }

    private fun failText(code: Int): String = when (code) {
        DownloadManager.ERROR_INSUFFICIENT_SPACE -> "Sem espaço de armazenamento suficiente"
        DownloadManager.ERROR_FILE_ERROR -> "Erro ao gravar o arquivo"
        DownloadManager.ERROR_HTTP_DATA_ERROR -> "Falha na transferência dos dados"
        DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "Redirecionamentos demais"
        DownloadManager.ERROR_CANNOT_RESUME -> "Não foi possível retomar o download"
        DownloadManager.ERROR_UNHANDLED_HTTP_CODE -> "Resposta inesperada do servidor"
        in 400..599 -> "O servidor respondeu HTTP $code (o link pode ter expirado ou não existir)"
        else -> "Erro no download ($code)"
    }

    private fun sha256Of(f: File): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        f.inputStream().use { st ->
            val b = ByteArray(65536)
            while (true) {
                val n = st.read(b)
                if (n < 0) break
                md.update(b, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun looksLikePkg(f: File): Boolean = try {
        f.inputStream().use { s ->
            val b = ByteArray(4)
            s.read(b) == 4 && b[0] == 0x7F.toByte() && b[1] == 0x43.toByte() && b[2] == 0x4E.toByte() && b[3] == 0x54.toByte()
        }
    } catch (e: Exception) {
        false
    }

    private fun watch(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            var lastBytes = -1L
            var lastT = 0L
            while (true) {
                val p = apps.value.firstOrNull { it.id == id } ?: return@launch
                if (p.status != "RUNNING") return@launch
                var found = false
                var st = 0
                var got = 0L
                var total = -1L
                var reason = 0
                dm.query(DownloadManager.Query().setFilterById(p.dmId))?.use { c ->
                    if (c.moveToFirst()) {
                        found = true
                        st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                        got = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                        total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                        reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                    }
                }
                if (!found) {
                    upd(id) { it.copy(status = "IDLE", detail = "Download removido do sistema") }
                    persist()
                    return@launch
                }
                val now = SystemClock.elapsedRealtime()
                if (lastBytes >= 0 && now > lastT) {
                    val inst = ((got - lastBytes) * 1000 / (now - lastT)).coerceAtLeast(0)
                    val prev = speeds.value[id] ?: inst
                    speeds.update { it + (id to ((prev + inst) / 2)) }
                }
                lastBytes = got
                lastT = now
                when (st) {
                    DownloadManager.STATUS_SUCCESSFUL -> {
                        val f = File(p.path)
                        speeds.update { it - id }
                        if (!f.isFile) {
                            upd(id) { it.copy(status = "FAILED", detail = "Arquivo não encontrado após o download") }
                            persist()
                            say("Falha: arquivo não encontrado após o download")
                        } else if (p.sha256 != null && !sha256Of(f).equals(p.sha256, ignoreCase = true)) {
                            f.delete()
                            upd(id) { it.copy(status = "FAILED", detail = "O SHA-256 não confere com o publicado (arquivo apagado)") }
                            persist()
                            say("O SHA-256 do arquivo não confere com o publicado pela fonte; ele foi apagado")
                        } else if (!looksLikePkg(f)) {
                            f.delete()
                            upd(id) { it.copy(status = "FAILED", detail = "O arquivo baixado não é um PKG de PS4 (apagado)") }
                            persist()
                            say("O arquivo baixado não é um PKG de PS4 e foi apagado")
                        } else {
                            upd(id) { it.copy(status = "DONE", received = f.length(), size = f.length(), detail = "Concluído${if (p.sha256 != null) " • SHA-256 conferido" else ""}") }
                            persist()
                            say("Download concluído: ${p.name}")
                            if (p.sendAfter) sendRequests.tryEmit(p.path)
                        }
                        return@launch
                    }
                    DownloadManager.STATUS_FAILED -> {
                        val msg = failText(reason)
                        upd(id) { it.copy(status = "FAILED", detail = msg) }
                        speeds.update { it - id }
                        persist()
                        say("Falha no download de ${p.name}: $msg")
                        return@launch
                    }
                    DownloadManager.STATUS_PAUSED -> upd(id) { it.copy(received = got, size = if (total > 0) total else it.size, detail = "Pausado (aguardando rede)") }
                    DownloadManager.STATUS_PENDING -> upd(id) { it.copy(detail = "Na fila") }
                    else -> upd(id) { it.copy(received = got, size = if (total > 0) total else it.size, detail = "Baixando") }
                }
                delay(500)
            }
        }
    }
}
