package com.dpireborn.app.data

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.dpireborn.app.util.CrashLog

/**
 * "Acesso a todos os arquivos" (MANAGE_EXTERNAL_STORAGE). Necessário porque, a partir do Android 11,
 * o seletor de pastas não deixa escolher a pasta Download nem a raiz do armazenamento.
 */
object StoragePermission {
    /** Pasta virtual da biblioteca que significa "procurar PKG em todo o armazenamento". */
    const val ALL_STORAGE_URI = "allfiles://"

    fun hasAllFiles(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }

    /**
     * Abre a tela onde o usuário liga "Permitir gerenciar todos os arquivos". Tenta, em ordem, a tela do próprio app
     * (Android 11+), a lista geral e os detalhes do app: alguns aparelhos não têm a primeira, e lançar uma Intent sem
     * tela correspondente derruba o app com ActivityNotFoundException. Devolve false se nenhuma abrir.
     */
    fun launchSettings(ctx: Context, launch: (Intent) -> Unit): Boolean {
        val pkg = Uri.parse("package:${ctx.packageName}")
        val options = ArrayList<Intent>()
        if (Build.VERSION.SDK_INT >= 30) {
            options.add(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkg))
            options.add(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
        }
        options.add(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg))
        for (i in options) {
            try {
                launch(i)
                return true
            } catch (e: Exception) {
                CrashLog.log("permissao", "tela ${i.action} indisponível", e)
            }
        }
        return false
    }

    fun settingsIntent(ctx: Context): Intent =
        if (Build.VERSION.SDK_INT >= 30) {
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
        } else {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
        }
}
