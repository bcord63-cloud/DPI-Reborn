package com.dpireborn.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.dpireborn.app.AppViewModel
import com.dpireborn.app.apps.AppsViewModel
import com.dpireborn.app.catalog.CatalogApp
import com.dpireborn.app.catalog.CatalogEntry
import com.dpireborn.app.catalog.CatalogFilters
import com.dpireborn.app.catalog.CatalogSorts
import com.dpireborn.app.catalog.CatalogViewModel
import com.dpireborn.app.catalog.SourceStatus
import com.dpireborn.app.catalog.UrlGuard
import com.dpireborn.app.ps4.YtAdblockViewModel
import com.dpireborn.app.ui.theme.DangerRed
import com.dpireborn.app.ui.theme.OutlineDim
import com.dpireborn.app.ui.theme.SuccessGreen
import com.dpireborn.app.ui.theme.SurfaceDark
import com.dpireborn.app.ui.theme.TextSecondary
import com.dpireborn.app.ui.theme.WarnAmber

private val categoryOrder = listOf("Emuladores", "Homebrew", "Mídia", "Ferramentas", "Outros")

fun openUrl(ctx: Context, url: String): Boolean {
    if (!UrlGuard.isSafeHttps(url)) return false
    return try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }
}

private fun categoryIcon(c: String): ImageVector = when (c) {
    "Emuladores" -> Icons.Filled.SportsEsports
    "Homebrew" -> Icons.Filled.Extension
    "Mídia" -> Icons.Filled.PlayCircle
    "Ferramentas" -> Icons.Filled.Build
    else -> Icons.Filled.Apps
}

@Composable
private fun chipColors() = FilterChipDefaults.filterChipColors(
    selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f),
    selectedLabelColor = Color.White,
    labelColor = TextSecondary,
)

/** Apps (exclusivo PS4): catálogo verificado, descoberta no GitHub e links próprios. */
@Composable
fun AppsScreen(cvm: CatalogViewModel, avm: AppsViewModel, vm: AppViewModel, yt: YtAdblockViewModel) {
    val selected by cvm.selectedId.collectAsStateWithLifecycle()
    val entries by cvm.entries.collectAsStateWithLifecycle()
    val loading by cvm.loading.collectAsStateWithLifecycle()
    var sub by rememberSaveable { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { cvm.ensureFresh() }
    val sel = entries.firstOrNull { it.app.id == selected }

    if (sel != null) {
        BackHandler { cvm.close() }
        if (sel.app.special == "youtube-adblock") YoutubeScreen(sel, cvm, vm, yt) else CatalogDetail(sel, cvm, avm)
        return
    }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        ScreenHeader(title = "Apps", subtitle = "Exclusivo PS4 • fontes verificadas ao vivo") {
            IconButton(onClick = { cvm.refresh() }, enabled = !loading) {
                if (loading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Filled.Refresh, contentDescription = "Atualizar catálogo", tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Catálogo", "Descobrir", "Meus links").forEachIndexed { i, label ->
                FilterChip(selected = sub == i, onClick = { sub = i }, label = { Text(label) }, colors = chipColors())
            }
        }
        Box(modifier = Modifier.weight(1f).padding(top = 8.dp)) {
            when (sub) {
                1 -> DiscoverPanel(cvm)
                2 -> MyLinksScreen(avm)
                else -> CatalogPanel(cvm)
            }
        }
    }
}

@Composable
private fun CatalogPanel(cvm: CatalogViewModel) {
    val visible by cvm.visible.collectAsStateWithLifecycle()
    val entries by cvm.entries.collectAsStateWithLifecycle()
    val query by cvm.query.collectAsStateWithLifecycle()
    val filter by cvm.filter.collectAsStateWithLifecycle()
    val sort by cvm.sort.collectAsStateWithLifecycle()
    val favorites by cvm.favorites.collectAsStateWithLifecycle()
    val recents by cvm.recents.collectAsStateWithLifecycle()
    val note by cvm.sourceNote.collectAsStateWithLifecycle()
    val problem by cvm.problem.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { cvm.query.value = it },
            singleLine = true,
            placeholder = { Text("Nome, emulador, plataforma, categoria ou desenvolvedor") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { cvm.query.value = "" }) { Icon(Icons.Filled.Close, contentDescription = "Limpar") }
                }
            },
            colors = fieldColors(),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth(),
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(CatalogFilters) { f ->
                FilterChip(selected = filter == f, onClick = { cvm.filter.value = f }, label = { Text(f) }, colors = chipColors())
            }
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 4.dp)) {
            items(CatalogSorts) { (key, label) ->
                FilterChip(selected = sort == key, onClick = { cvm.sort.value = key }, label = { Text(label, fontSize = 12.sp) }, colors = chipColors())
            }
        }
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp, top = 4.dp),
        ) {
            item {
                Column {
                    Text("${entries.size} itens • $note", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    problem?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = WarnAmber) }
                }
            }
            if (visible.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().height(220.dp)) {
                        EmptyState(
                            icon = Icons.Filled.Search,
                            title = if (filter == "Favoritos") "Nenhum favorito ainda" else "Nada encontrado",
                            text = if (filter == "Favoritos") "Toque na estrela de um app para guardá-lo aqui." else "Tente outro termo ou filtro.",
                        )
                    }
                }
            } else if (query.isBlank() && filter == "Todos") {
                val groups = visible.groupBy { it.app.category }
                val ordered = categoryOrder.filter { it in groups } + groups.keys.filter { it !in categoryOrder }
                for (cat in ordered) {
                    item(key = "h-$cat") {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                            Icon(categoryIcon(cat), contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Text("  $cat", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    items(groups[cat].orEmpty(), key = { it.app.id }) { e ->
                        AppCard(e, e.app.id in favorites, { cvm.toggleFavorite(e.app.id) }, { cvm.open(e.app.id) })
                    }
                }
                if ("Mídia" !in groups) {
                    item { Text("Mídia: nenhum app de mídia para PS4 foi verificado ainda além do YouTube.", style = MaterialTheme.typography.bodySmall, color = TextSecondary) }
                }
            } else {
                items(visible, key = { it.app.id }) { e ->
                    AppCard(e, e.app.id in favorites, { cvm.toggleFavorite(e.app.id) }, { cvm.open(e.app.id) })
                }
            }
            if (recents.isNotEmpty() && query.isBlank()) {
                item {
                    val names = recents.mapNotNull { id -> entries.firstOrNull { it.app.id == id }?.app?.name }
                    if (names.isNotEmpty()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Vistos: ${names.joinToString(", ")}", style = MaterialTheme.typography.labelSmall, color = TextSecondary, modifier = Modifier.weight(1f), maxLines = 2)
                            TextButton(onClick = { cvm.clearRecents() }) { Text("Limpar") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DiscoverPanel(cvm: CatalogViewModel) {
    val ctx = LocalContext.current
    val results by cvm.discovered.collectAsStateWithLifecycle()
    val busy by cvm.discovering.collectAsStateWithLifecycle()
    val error by cvm.discoverError.collectAsStateWithLifecycle()
    var term by rememberSaveable { mutableStateOf("") }
    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            "Procura projetos de PS4 no GitHub (API oficial). Os resultados NÃO são verificados: confira o autor, o README e as releases antes de usar qualquer coisa.",
            style = MaterialTheme.typography.bodySmall, color = TextSecondary,
        )
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
            OutlinedTextField(
                value = term, onValueChange = { term = it }, singleLine = true,
                placeholder = { Text("ex.: homebrew, emulator, payload") },
                colors = fieldColors(), shape = RoundedCornerShape(16.dp), modifier = Modifier.weight(1f),
            )
            FilledTonalButton(onClick = { cvm.discover(term) }, enabled = !busy && term.isNotBlank(), modifier = Modifier.padding(start = 8.dp)) {
                if (busy) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp) else Text("Buscar")
            }
        }
        error?.let { Text(it, color = WarnAmber, style = MaterialTheme.typography.bodySmall) }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(results, key = { it.fullName }) { c ->
                SectionCard {
                    Text(c.fullName, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (c.description.isNotBlank()) Text(c.description, style = MaterialTheme.typography.bodySmall, color = TextSecondary, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    Text(
                        "★ ${c.stars} • atualizado em ${formatDate(c.updatedAt)} • não verificado",
                        style = MaterialTheme.typography.labelSmall, color = WarnAmber, modifier = Modifier.padding(top = 4.dp),
                    )
                    OutlinedButton(onClick = { openUrl(ctx, c.url) }, modifier = Modifier.padding(top = 8.dp)) {
                        Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text("  Abrir no GitHub")
                    }
                }
            }
        }
    }
}

@Composable
fun AppIcon(app: CatalogApp, size: Dp) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(size / 3.5f))
            .background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, Color(0xFF2E1065)))),
        contentAlignment = Alignment.Center,
    ) {
        Icon(categoryIcon(app.category), contentDescription = null, tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.size(size / 2))
        app.iconUrl?.let {
            AsyncImage(model = it, contentDescription = app.name, contentScale = ContentScale.Crop, modifier = Modifier.size(size))
        }
    }
}

@Composable
fun StatusChip(e: CatalogEntry) {
    val (text, color) = when (e.status) {
        SourceStatus.DOWNLOAD -> "Arquivo verificado" to SuccessGreen
        SourceStatus.LINK -> "Fonte online" to SuccessGreen
        SourceStatus.UNCHECKED -> "Não verificado" to TextSecondary
        SourceStatus.UNAVAILABLE -> "Fonte indisponível" to DangerRed
    }
    Text(
        text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(color.copy(alpha = 0.14f)).padding(horizontal = 8.dp, vertical = 2.dp),
    )
}

@Composable
private fun AppCard(e: CatalogEntry, fav: Boolean, onFav: () -> Unit, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        border = BorderStroke(1.dp, OutlineDim),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column {
            e.app.coverUrl?.let {
                AsyncImage(
                    model = it, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().height(110.dp).background(Brush.horizontalGradient(listOf(Color(0xFF2E1065), Color(0xFF110F1A)))),
                )
            }
            Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                AppIcon(e.app, 48.dp)
                Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(e.app.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "${e.app.category}${e.app.emulates?.let { " • $it" } ?: ""}",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                    Text(e.app.description, style = MaterialTheme.typography.bodySmall, color = TextSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                        StatusChip(e)
                        e.release?.let { Text("  ${it.version}", style = MaterialTheme.typography.labelSmall, color = TextSecondary, maxLines = 1) }
                        if (e.hasUpdate) Text("  • atualizado", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                    }
                }
                IconButton(onClick = onFav) {
                    Icon(
                        if (fav) Icons.Filled.Star else Icons.Filled.StarBorder,
                        contentDescription = if (fav) "Remover dos favoritos" else "Favoritar",
                        tint = if (fav) WarnAmber else TextSecondary,
                    )
                }
            }
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = TextSecondary, modifier = Modifier.width(110.dp))
        Text(value, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
    }
}

@Composable
fun ExternalSourceWarning(text: String) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = WarnAmber.copy(alpha = 0.08f)),
        border = BorderStroke(1.dp, WarnAmber.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Filled.Warning, contentDescription = null, tint = WarnAmber, modifier = Modifier.size(20.dp))
            Text("  $text", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun DetailHeader(e: CatalogEntry, cvm: CatalogViewModel) {
    val favorites by cvm.favorites.collectAsStateWithLifecycle()
    val fav = e.app.id in favorites
    Column {
        e.app.coverUrl?.let {
            AsyncImage(
                model = it, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(18.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF2E1065), Color(0xFF110F1A)))),
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
            IconButton(onClick = { cvm.close() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar") }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { cvm.toggleFavorite(e.app.id) }) {
                Icon(
                    if (fav) Icons.Filled.Star else Icons.Filled.StarBorder,
                    contentDescription = if (fav) "Remover dos favoritos" else "Favoritar",
                    tint = if (fav) WarnAmber else TextSecondary,
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon(e.app, 72.dp)
            Column(modifier = Modifier.padding(start = 14.dp)) {
                Text(e.app.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(e.app.developer, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                Row(modifier = Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    StatusChip(e)
                    if (e.hasUpdate) Text("  • nova versão", color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        if (e.app.description.isNotBlank()) Text(e.app.description, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 14.dp))
        e.note?.let {
            Text(it, style = MaterialTheme.typography.bodySmall, color = if (e.status == SourceStatus.UNAVAILABLE) DangerRed else WarnAmber, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

@Composable
fun DetailInfo(e: CatalogEntry) {
    val r = e.release
    SectionCard {
        InfoRow("Categoria", e.app.category)
        InfoRow("Plataforma", e.app.platforms.joinToString(", ").ifBlank { "Não informada" })
        e.app.emulates?.let { InfoRow("Emula", it) }
        InfoRow("Versão", r?.let { it.version + if (it.prerelease) " (pré-lançamento)" else "" } ?: "Veja na página do projeto")
        InfoRow("Desenvolvedor", e.app.developer)
        r?.publisher?.let { InfoRow("Publicado por", it) }
        InfoRow("Fonte original", UrlGuard.host(e.app.sourceUrl))
        InfoRow("Atualização", if (r != null && r.publishedAt > 0) formatDate(r.publishedAt) else "Não disponível")
        InfoRow("Tamanho", if (r != null && r.size > 0) formatSize(r.size) else "Não disponível")
        r?.assetName?.let { InfoRow("Arquivo", it) }
        e.app.license?.let { InfoRow("Licença", it) }
        e.app.compat?.let { InfoRow("Compatibilidade", it) }
        r?.let { rel ->
            rel.downloadUrl?.let { dl ->
                InfoRow("SHA-256", rel.sha256 ?: "A fonte não publicou hash; não é possível conferir")
                InfoRow("Link", dl)
            }
        }
        InfoRow("Verificado em", if (e.checkedAt > 0) formatDate(e.checkedAt) else "Ainda não verificado")
    }
}

@Composable
private fun CatalogDetail(e: CatalogEntry, cvm: CatalogViewModel, avm: AppsViewModel) {
    val ctx = LocalContext.current
    val apps by avm.apps.collectAsStateWithLifecycle()
    val speeds by avm.speeds.collectAsStateWithLifecycle()
    val url = e.release?.downloadUrl
    val rec = if (url != null) apps.firstOrNull { it.url == url } else null

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        DetailHeader(e, cvm)
        Spacer(Modifier.height(14.dp))
        DetailInfo(e)
        Spacer(Modifier.height(12.dp))
        if (rec != null) {
            AppPkgCard(rec, speeds[rec.id] ?: 0L, avm)
        } else if (e.canDownloadPkg && url != null) {
            SectionCard {
                Text("Baixar pelo celular (sem limite de 30 MB) e enviar ao PS4 pelo mesmo mecanismo da Biblioteca.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                    Button(onClick = { avm.addAndStart(e.app.name, url, e.release?.sha256, true) }) {
                        Icon(Icons.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                        Text("  Baixar e enviar")
                    }
                    OutlinedButton(onClick = { avm.addAndStart(e.app.name, url, e.release?.sha256, false) }) { Text("Só baixar") }
                }
            }
        } else {
            SectionCard {
                Text(
                    if (e.status == SourceStatus.UNAVAILABLE) "A fonte não respondeu, então não há download agora."
                    else if (e.release?.assetName != null) "O arquivo desta release (${e.release?.assetName}) não é um PKG. Baixe e instale pela página do projeto, seguindo as instruções dele."
                    else "Este item não tem um PKG verificado para baixar aqui. Use a página do projeto.",
                    style = MaterialTheme.typography.bodyMedium, color = TextSecondary,
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = { if (!openUrl(ctx, e.app.sourceUrl)) cvm.query.value = cvm.query.value },
            modifier = Modifier.fillMaxWidth(),
        ) {
            Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
            Text("  Abrir página do projeto")
        }
        Spacer(Modifier.height(10.dp))
        ExternalSourceWarning(
            "Fonte externa: o DPI Reborn não hospeda nem altera este arquivo. Use só o que você tem direito de usar. " +
                "O arquivo é conferido (PKG e SHA-256 quando existe) e nunca é instalado sozinho.",
        )
        Spacer(Modifier.height(24.dp))
    }
}
