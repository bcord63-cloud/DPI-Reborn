package com.dpireborn.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dpireborn.app.ui.theme.SuccessGreen
import com.dpireborn.app.ui.theme.TextSecondary
import com.dpireborn.app.ui.theme.WarnAmber
import com.dpireborn.app.util.CrashLog
import org.json.JSONObject

private data class ChangeVersion(
    val version: String,
    val title: String,
    val date: String?,
    val status: String,
    val sections: List<Pair<String, List<String>>>,
)

/** Histórico de versões, lido de assets/changelog.json. */
@Composable
fun ChangelogScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val data = remember {
        try {
            val root = JSONObject(ctx.assets.open("changelog.json").bufferedReader().use { it.readText() })
            val arr = root.getJSONArray("versions")
            val list = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val sec = o.optJSONObject("sections")
                val sections = ArrayList<Pair<String, List<String>>>()
                sec?.keys()?.forEach { k ->
                    val a = sec.getJSONArray(k)
                    sections.add(k to (0 until a.length()).map { j -> a.getString(j) })
                }
                ChangeVersion(
                    o.getString("version"), o.optString("title"), if (o.isNull("date")) null else o.optString("date"),
                    o.optString("status"), sections,
                )
            }
            root.optString("nota") to list
        } catch (e: Exception) {
            CrashLog.log("changelog", "falha ao ler o changelog", e)
            "" to emptyList()
        }
    }
    androidx.activity.compose.BackHandler { onBack() }
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar") }
            Text("Changelogs", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        if (data.first.isNotBlank()) Text(data.first, style = MaterialTheme.typography.bodySmall, color = TextSecondary, modifier = Modifier.padding(vertical = 6.dp))
        if (data.second.isEmpty()) {
            EmptyState(Icons.AutoMirrored.Filled.ArrowBack, "Sem histórico", "Não foi possível ler o changelog.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                items(data.second, key = { it.version }) { v ->
                    SectionCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(v.version, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text(
                                when (v.status) { "current" -> "ATUAL"; "planned" -> "PLANEJADO"; else -> "" },
                                style = MaterialTheme.typography.labelSmall,
                                color = if (v.status == "current") SuccessGreen else WarnAmber,
                            )
                        }
                        Text(
                            v.title + " • " + (v.date ?: "data não disponível"),
                            style = MaterialTheme.typography.bodySmall, color = TextSecondary,
                        )
                        v.sections.forEach { (name, items) ->
                            Text(name, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 10.dp))
                            items.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 2.dp)) }
                        }
                    }
                }
            }
        }
    }
}
