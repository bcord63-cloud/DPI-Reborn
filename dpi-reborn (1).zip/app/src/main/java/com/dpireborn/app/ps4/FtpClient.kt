package com.dpireborn.app.ps4

import java.io.BufferedReader
import java.io.Closeable
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket

/** Cliente FTP mínimo (modo passivo, binário) para o servidor FTP do GoldHEN. Bloqueante: use fora da thread principal. */
class FtpClient(private val host: String, private val port: Int) : Closeable {
    class Reply(val code: Int, val text: String)

    private var sock: Socket? = null
    private var rd: BufferedReader? = null
    private var wr: OutputStream? = null

    fun connect() {
        val s = Socket()
        s.connect(InetSocketAddress(host, port), 6000)
        s.soTimeout = 15000
        sock = s
        rd = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.ISO_8859_1))
        wr = s.getOutputStream()
        val r = read()
        if (r.code !in 200..299) throw IOException("Resposta inicial inesperada: ${r.text}")
    }

    private fun read(): Reply {
        val reader = rd ?: throw IOException("Sem conexão")
        val first = reader.readLine() ?: throw IOException("Conexão encerrada pelo PS4")
        val code = first.take(3).toIntOrNull() ?: throw IOException("Resposta inválida: $first")
        var text = first
        if (first.length > 3 && first[3] == '-') {
            while (true) {
                val l = reader.readLine() ?: throw IOException("Conexão encerrada pelo PS4")
                text += "\n" + l
                if (l.length >= 4 && l.startsWith(code.toString()) && l[3] == ' ') break
            }
        }
        return Reply(code, text)
    }

    fun cmd(line: String): Reply {
        val w = wr ?: throw IOException("Sem conexão")
        w.write((line + "\r\n").toByteArray(Charsets.ISO_8859_1))
        w.flush()
        return read()
    }

    fun login() {
        val u = cmd("USER anonymous")
        if (u.code == 230) return
        if (u.code != 331) throw IOException("Login recusado: ${u.text}")
        val p = cmd("PASS dpi@reborn")
        if (p.code != 230) throw IOException("Login recusado: ${p.text}")
    }

    fun dirExists(path: String): Boolean = cmd("CWD $path").code in 200..299

    fun size(path: String): Long? {
        cmd("TYPE I")
        val r = cmd("SIZE $path")
        return if (r.code == 213) r.text.substringAfter(' ').trim().toLongOrNull() else null
    }

    fun mkdir(path: String): Boolean = cmd("MKD $path").code in listOf(257, 250)

    private fun openData(): Socket {
        val r = cmd("PASV")
        if (r.code != 227) throw IOException("O PS4 recusou o modo passivo: ${r.text}")
        val m = Regex("(\\d+),(\\d+),(\\d+),(\\d+),(\\d+),(\\d+)").find(r.text)
            ?: throw IOException("Resposta PASV inválida: ${r.text}")
        val dataPort = m.groupValues[5].toInt() * 256 + m.groupValues[6].toInt()
        val s = Socket()
        s.connect(InetSocketAddress(host, dataPort), 6000)
        s.soTimeout = 15000
        return s
    }

    /** Lê um arquivo. Null se não existe (ou não pôde ser aberto). */
    fun retr(path: String): ByteArray? {
        cmd("TYPE I")
        val d = openData()
        try {
            val r = cmd("RETR $path")
            if (r.code != 125 && r.code != 150) return null
            val bytes = d.getInputStream().readBytes()
            d.close()
            val end = read()
            if (end.code !in 200..299) throw IOException("Falha ao ler $path: ${end.text}")
            return bytes
        } finally {
            d.close()
        }
    }

    fun stor(path: String, data: ByteArray) {
        cmd("TYPE I")
        val d = openData()
        try {
            val r = cmd("STOR $path")
            if (r.code != 125 && r.code != 150) throw IOException("O PS4 recusou gravar $path: ${r.text}")
            d.getOutputStream().use { it.write(data) }
            val end = read()
            if (end.code !in 200..299) throw IOException("Falha ao gravar $path: ${end.text}")
        } finally {
            d.close()
        }
    }

    override fun close() {
        try {
            cmd("QUIT")
        } catch (e: Exception) {
            // já fechado
        }
        try {
            sock?.close()
        } catch (e: Exception) {
            // ignora
        }
    }
}
