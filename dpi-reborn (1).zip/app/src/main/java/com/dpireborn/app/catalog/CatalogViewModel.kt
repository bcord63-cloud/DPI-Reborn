package com.dpireborn.app.catalog

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dpireborn.app.util.CrashLog
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONArray
import java.io.File

val CatalogFilters = listOf("Todos", "Emuladores", "Homebrew", "Mídia", "Ferramentas", "Outros", "Favoritos")
val CatalogSorts = listOf("recent" to "Mais recentes", "name" to "Nome", "updated" to "Atualizados recentemente")

class CatalogViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val repo = CatalogRepository(ctx)
    private val favFile = File(ctx.filesDir, "fav_catalog.json")
    private val recentFile = File(ctx.filesDir, "recent_catalog.json")

    val entries = MutableStateFlow<List<CatalogEntry>>(emptyList())
    val loading = MutableStateFlow(false)
    val sourceNote = MutableStateFlow("")
    val problem = MutableStateFlow<String?>(null)

    val query = MutableStateFlow("")
    val filter = MutableStateFlow("Todos")
    val sort = MutableStateFlow("recent")
    val selectedId = MutableStateFlow<String?>(null)
    val favorites = MutableStateFlow(readList(favFile).toSet())
    val recents = MutableStateFlow(readList(recentFile))

    val discovering = MutableStateFlow(false)
    val discovered = MutableStateFlow<List<Candidate>>(emptyList())
    val discoverError = MutableStateFlow<String?>(null)

    val visible: StateFlow<List<CatalogEntry>> =
        combine(entries, query, filter, sort, favorites) { list, q, f, s, fav ->
            val needle = q.trim().lowercase()
            val filtered = list.filter { e ->
                val a = e.app
                val byFilter = when (f) {
                    "Favoritos" -> a.id in fav
                    "Todos" -> true
                    else -> a.category == f
                }
                byFilter && (needle.isEmpty() ||
                    a.name.lowercase().contains(needle) ||
                    a.developer.lowercase().contains(needle) ||
                    a.category.lowercase().contains(needle) ||
                    a.description.lowercase().contains(needle) ||
                    (a.emulates ?: "").lowercase().contains(needle) ||
                    a.platforms.any { it.lowercase().contains(needle) })
            }
            when (s) {
                "name" -> filtered.sortedBy { it.app.name.lowercase() }
                "updated" -> filtered.sortedWith(
                    compareByDescending<CatalogEntry> { it.release?.publishedAt ?: 0L }.thenBy { it.app.name.lowercase() }
                )
                else -> filtered.sortedWith(
                    compareByDescending<CatalogEntry> { it.app.added }.thenBy { it.app.name.lowercase() }
                )
            }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        try {
            val (apps, origin) = repo.loadApps()
            entries.value = repo.loadEntries(apps)
            sourceNote.value = origin
        } catch (e: Exception) {
            CrashLog.log("catalogo", "falha ao carregar o catálogo", e)
            problem.value = "Não foi possível carregar o catálogo: ${e.message}"
        }
    }

    private fun readList(f: File): List<String> = try {
        val a = if (f.exists()) JSONArray(f.readText()) else JSONArray()
        (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() }
    } catch (e: Exception) {
        emptyList()
    }

    private fun writeList(f: File, l: Collection<String>) {
        try {
            val a = JSONArray()
            l.forEach { a.put(it) }
            f.writeText(a.toString())
        } catch (e: Exception) {
            CrashLog.log("catalogo", "falha ao salvar ${f.name}", e)
        }
    }

    /** Só consulta a rede se a última verificação tem mais de 6 horas (ou nunca houve). */
    fun ensureFresh() {
        val last = entries.value.maxOfOrNull { it.checkedAt } ?: 0L
        if (System.currentTimeMillis() - last > 6 * 3600_000L) refresh()
    }

    fun refresh() {
        if (loading.value) return
        loading.value = true
        viewModelScope.launch {
            try {
                problem.value = repo.fetchRemote()
                val (apps, origin) = repo.loadApps()
                sourceNote.value = origin
                val prev = entries.value.associateBy { it.app.id }
                val sem = Semaphore(4)
                val res = coroutineScope {
                    apps.map { a -> async { sem.withPermit { repo.verify(a, prev[a.id]) } } }.awaitAll()
                }
                entries.value = res
                repo.saveStates(res)
            } catch (e: Exception) {
                CrashLog.log("catalogo", "falha ao verificar fontes", e)
                problem.value = "Falha ao verificar as fontes: ${e.message}"
            } finally {
                loading.value = false
            }
        }
    }

    fun discover(term: String) {
        if (discovering.value || term.isBlank()) return
        discovering.value = true
        discoverError.value = null
        viewModelScope.launch {
            try {
                discovered.value = repo.discover(term)
                if (discovered.value.isEmpty()) discoverError.value = "Nenhum projeto encontrado para \"$term\""
            } catch (e: Exception) {
                discoverError.value = "Busca indisponível agora (limite da API do GitHub ou sem internet)"
            } finally {
                discovering.value = false
            }
        }
    }

    fun open(id: String) {
        selectedId.value = id
        val l = (listOf(id) + recents.value.filter { it != id }).take(12)
        recents.value = l
        writeList(recentFile, l)
    }

    fun close() {
        selectedId.value = null
    }

    fun toggleFavorite(id: String) {
        val s = if (id in favorites.value) favorites.value - id else favorites.value + id
        favorites.value = s
        writeList(favFile, s)
    }

    fun clearRecents() {
        recents.value = emptyList()
        writeList(recentFile, emptyList())
    }
}
