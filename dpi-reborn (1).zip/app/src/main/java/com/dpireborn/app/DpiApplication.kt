package com.dpireborn.app

import android.app.Application
import com.dpireborn.app.util.CrashLog

class DpiApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
    }
}
