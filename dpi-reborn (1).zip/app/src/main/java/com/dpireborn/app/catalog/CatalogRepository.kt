package com.dpireborn.app.catalog

import android.content.Context
import com.dpireborn.app.util.CrashLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

private class GhHttpException(val code: Int) : Exception("HTTP $code")

/**
 * Catálogo atualizável de apps de PS4: lê o catalog.json (online > cópia salva > embutido) e confere cada fonte ao
 * vivo. Versão, tamanho, data, link e SHA-256 vêm da própria fonte (API de releases do GitHub). O catálogo diz só
 * QUAL projeto existe, de que categoria é e que arquivo procurar.
 */
class CatalogRepository(private val ctx: Context) {
    companion object {
        const val CATALOG_URL =
            "https://raw.githubusercontent.com/bcord63-cloud/DPI-Reborn/main/catalog/catalog.json"
        private const val UA = "DPI-Reborn (Android)"
        private const val GH_ACCEPT = "application/vnd.github+json"
        private const val MAX_BYTES = 1_000_000
        private val repoRegex = Regex("^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")
    }

    private val remoteFile = File(ctx.filesDir, "catalog_remote.json")
    private val stateFile = File(ctx.filesDir, "catalog_state.json")

    private class Http(val code: Int, val body: String)

    private fun dateOf(s: String?): Long {
        if (s.isNullOrBlank()) return 0L
        for (p in listOf("yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd")) {
            try {
                val f = SimpleDateFormat(p, Locale.US)
                f.timeZone = TimeZone.getTimeZone("UTC")
                return f.parse(s)?.time ?: continue
            } catch (e: Exception) {
                // tenta o próximo formato
            }
        }
        return 0L
    }

    private fun JSONArray?.strings(): List<String> {
        val out = ArrayList<String>()
        if (this == null) return out
        for (i in 0 until length()) optString(i).takeIf { it.isNotBlank() }?.let { out.add(it) }
        return out
    }

    private fun JSONObject.optStr(key: String): String? = optString(key, "").ifBlank { null }

    fun parseCatalog(text: String): List<CatalogApp> {
        val arr = JSONObject(text).getJSONArray("apps")
        val out = ArrayList<CatalogApp>()
        for (i in 0 until arr.length()) {
            try {
                val o = arr.getJSONObject(i)
                val src = o.getString("sourceUrl")
                if (!UrlGuard.isSafeHttps(src)) continue
                out.add(
                    CatalogApp(
                        id = o.getString("id"), name = o.getString("name"),
                        description = o.optString("description", ""),
                        category = o.optString("category", "Outros"),
                        platforms = o.optJSONArray("platforms").strings(),
                        developer = o.optString("developer", "Não informado"),
                        sourceUrl = src,
                        github = o.optStr("github")?.takeIf { repoRegex.matches(it) },
                        assetRegex = o.optStr("assetRegex"), license = o.optStr("license"),
                        added = dateOf(o.optString("added", "")),
                        removed = o.optBoolean("removed", false),
                        compat = o.optStr("compat"), emulates = o.optStr("emulates"), special = o.optStr("special"),
                    )
                )
            } catch (e: Exception) {
                CrashLog.log("catalogo", "entrada malformada ignorada", e)
            }
        }
        return out.filter { !it.removed }.distinctBy { it.id }
    }

    fun loadApps(): Pair<List<CatalogApp>, String> {
        try {
            if (remoteFile.exists()) {
                val l = parseCatalog(remoteFile.readText())
                if (l.isNotEmpty()) return l to "Catálogo atualizado pela internet (cópia salva)"
            }
        } catch (e: Exception) {
            CrashLog.log("catalogo", "cópia salva corrompida", e)
        }
        val text = ctx.assets.open("catalog.json").bufferedReader().use { it.readText() }
        return parseCatalog(text) to "Catálogo embutido no app"
    }

    private fun request(url: String, method: String = "GET", accept: String? = null, readBody: Boolean = true): Http {
        require(UrlGuard.isSafeHttps(url)) { "URL não permitida" }
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", UA)
            if (accept != null) c.setRequestProperty("Accept", accept)
            val code = c.responseCode
            var body = ""
            if (readBody && code in 200..299) {
                c.inputStream.use { s ->
                    val buf = ByteArrayOutputStream()
                    val b = ByteArray(8192)
                    var total = 0
                    while (true) {
                        val n = s.read(b)
                        if (n < 0) break
                        total += n
                        if (total > MAX_BYTES) throw IOException("Resposta grande demais")
                        buf.write(b, 0, n)
                    }
                    body = buf.toString("UTF-8")
                }
            }
            return Http(code, body)
        } finally {
            c.disconnect()
        }
    }

    /** Baixa o catalog.json do repositório. Devolve uma mensagem de problema, ou null se atualizou. */
    suspend fun fetchRemote(): String? = withContext(Dispatchers.IO) {
        try {
            val r = request(CATALOG_URL, accept = "application/json")
            if (r.code != 200) return@withContext "Catálogo online indisponível (HTTP ${r.code}); usando o último salvo"
            if (parseCatalog(r.body).isEmpty()) return@withContext "Catálogo online inválido ou vazio; usando o último salvo"
            val tmp = File(remoteFile.parentFile, remoteFile.name + ".tmp")
            tmp.writeText(r.body)
            if (!tmp.renameTo(remoteFile)) remoteFile.writeText(r.body)
            null
        } catch (e: Exception) {
            "Sem conexão com o catálogo online; usando o último salvo"
        }
    }

    suspend fun verify(app: CatalogApp, previous: CatalogEntry?): CatalogEntry = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        try {
            val e = if (app.github != null) verifyGithub(app, now) else verifyPage(app, now)
            e.copy(previousVersion = previous?.release?.version)
        } catch (e: GhHttpException) {
            if (e.code == 403 || e.code == 429) {
                CatalogEntry(
                    app, previous?.release, previous?.status ?: SourceStatus.UNCHECKED,
                    "Limite de consultas do GitHub atingido; mostrando a última verificação", previous?.checkedAt ?: 0L,
                    previous?.previousVersion,
                )
            } else {
                CatalogEntry(app, null, SourceStatus.UNAVAILABLE, "O GitHub respondeu HTTP ${e.code}", now)
            }
        } catch (e: Exception) {
            CatalogEntry(
                app, previous?.release, SourceStatus.UNAVAILABLE,
                "Não foi possível consultar a fonte agora (sem internet ou fora do ar)", now,
                previous?.previousVersion,
            )
        }
    }

    private fun latestRelease(base: String): JSONObject? {
        val r = request("$base/releases/latest", accept = GH_ACCEPT)
        if (r.code == 200) return JSONObject(r.body)
        if (r.code != 404) throw GhHttpException(r.code)
        val l = request("$base/releases?per_page=5", accept = GH_ACCEPT)
        if (l.code == 404) return null
        if (l.code != 200) throw GhHttpException(l.code)
        val a = JSONArray(l.body)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (!o.optBoolean("draft")) return o
        }
        return null
    }

    private fun verifyGithub(app: CatalogApp, now: Long): CatalogEntry {
        val rel = latestRelease("https://api.github.com/repos/${app.github}")
            ?: return CatalogEntry(app, null, SourceStatus.LINK, "Nenhuma release publicada neste repositório. Veja a página do projeto.", now)
        val tag = rel.optString("tag_name", "").ifBlank { rel.optString("name", "?") }
        val pre = rel.optBoolean("prerelease")
        val published = dateOf(rel.optString("published_at", ""))
        val publisher = rel.optJSONObject("author")?.optStr("login")
        val htmlUrl = rel.optString("html_url", "").takeIf { UrlGuard.isSafeHttps(it) }
        val re = app.assetRegex?.let { try { Regex(it) } catch (e: Exception) { null } }
        val assets = rel.optJSONArray("assets") ?: JSONArray()
        var chosen: JSONObject? = null
        for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            if (re == null || re.containsMatchIn(a.optString("name", ""))) {
                chosen = a
                break
            }
        }
        val dl = chosen?.optString("browser_download_url", "") ?: ""
        val host = UrlGuard.host(dl)
        val okUrl = UrlGuard.isSafeHttps(dl) && (host == "github.com" || host.endsWith(".github.com") || host.endsWith("githubusercontent.com"))
        if (chosen == null || !okUrl) {
            val r = ResolvedRelease(tag, published, publisher, null, 0L, null, null, pre, htmlUrl)
            return CatalogEntry(app, r, SourceStatus.LINK, "Release $tag encontrada, mas sem arquivo compatível. Use a página do projeto.", now)
        }
        val digest = chosen.optString("digest", "").removePrefix("sha256:").takeIf { it.length == 64 }
        val r = ResolvedRelease(
            tag, published, publisher, chosen.optString("name", "arquivo"), chosen.optLong("size", 0L),
            dl, digest, pre, htmlUrl,
        )
        return CatalogEntry(app, r, SourceStatus.DOWNLOAD, null, now)
    }

    private fun verifyPage(app: CatalogApp, now: Long): CatalogEntry {
        var r = request(app.sourceUrl, "HEAD", readBody = false)
        if (r.code == 403 || r.code == 405 || r.code == 501) r = request(app.sourceUrl, "GET", readBody = false)
        return when {
            r.code in 200..399 -> CatalogEntry(app, null, SourceStatus.LINK, "Página respondeu normalmente", now)
            r.code == 401 || r.code == 403 || r.code == 429 || r.code == 999 -> CatalogEntry(
                app, null, SourceStatus.LINK, "O site não permite verificação automática; abra a página para confirmar", now,
            )
            else -> CatalogEntry(app, null, SourceStatus.UNAVAILABLE, "A página respondeu HTTP ${r.code}", now)
        }
    }

    /** Busca projetos no GitHub (API oficial). Resultados NÃO são verificados nem tratados como confiáveis. */
    suspend fun discover(term: String): List<Candidate> = withContext(Dispatchers.IO) {
        val q = URLEncoder.encode("${term.trim()} ps4 in:name,description,topics", "UTF-8")
        val r = request("https://api.github.com/search/repositories?q=$q&sort=updated&per_page=15", accept = GH_ACCEPT)
        if (r.code != 200) throw GhHttpException(r.code)
        val items = JSONObject(r.body).optJSONArray("items") ?: JSONArray()
        val out = ArrayList<Candidate>()
        for (i in 0 until items.length()) {
            val o = items.getJSONObject(i)
            val url = o.optString("html_url", "")
            if (!UrlGuard.isSafeHttps(url)) continue
            out.add(
                Candidate(
                    o.optString("full_name", "?"), o.optString("description", "").let { if (it == "null") "" else it },
                    o.optInt("stargazers_count"), dateOf(o.optString("pushed_at", "")), url,
                )
            )
        }
        out
    }

    // ---------- Última verificação salva (aparece mesmo sem internet) ----------

    fun saveStates(list: List<CatalogEntry>) {
        try {
            val arr = JSONArray()
            for (e in list) {
                val o = JSONObject().put("id", e.app.id).put("status", e.status.name)
                    .put("note", e.note ?: JSONObject.NULL).put("checkedAt", e.checkedAt)
                    .put("prev", e.previousVersion ?: JSONObject.NULL)
                e.release?.let { r ->
                    o.put(
                        "release",
                        JSONObject().put("version", r.version).put("publishedAt", r.publishedAt)
                            .put("publisher", r.publisher ?: JSONObject.NULL)
                            .put("assetName", r.assetName ?: JSONObject.NULL).put("size", r.size)
                            .put("url", r.downloadUrl ?: JSONObject.NULL).put("sha256", r.sha256 ?: JSONObject.NULL)
                            .put("pre", r.prerelease).put("page", r.releaseUrl ?: JSONObject.NULL)
                    )
                }
                arr.put(o)
            }
            val tmp = File(stateFile.parentFile, stateFile.name + ".tmp")
            tmp.writeText(arr.toString())
            if (!tmp.renameTo(stateFile)) stateFile.writeText(arr.toString())
        } catch (e: Exception) {
            CrashLog.log("catalogo", "não foi possível salvar a verificação", e)
        }
    }

    fun loadEntries(apps: List<CatalogApp>): List<CatalogEntry> {
        val saved = HashMap<String, JSONObject>()
        try {
            if (stateFile.exists()) {
                val arr = JSONArray(stateFile.readText())
                for (i in 0 until arr.length()) saved[arr.getJSONObject(i).getString("id")] = arr.getJSONObject(i)
            }
        } catch (e: Exception) {
            saved.clear()
        }
        fun s(o: JSONObject, k: String): String? = if (o.has(k) && !o.isNull(k)) o.getString(k) else null
        return apps.map { a ->
            val o = saved[a.id] ?: return@map CatalogEntry(a, null, SourceStatus.UNCHECKED, null, 0L)
            try {
                val r = o.optJSONObject("release")?.let {
                    ResolvedRelease(
                        it.getString("version"), it.optLong("publishedAt"), s(it, "publisher"), s(it, "assetName"),
                        it.optLong("size"), s(it, "url")?.takeIf { u -> UrlGuard.isSafeHttps(u) }, s(it, "sha256"),
                        it.optBoolean("pre"), s(it, "page"),
                    )
                }
                CatalogEntry(a, r, SourceStatus.valueOf(o.getString("status")), s(o, "note"), o.optLong("checkedAt"), s(o, "prev"))
            } catch (e: Exception) {
                CatalogEntry(a, null, SourceStatus.UNCHECKED, null, 0L)
            }
        }
    }
}
