package com.dpireborn.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dpireborn.app.ui.theme.OutlineDim
import com.dpireborn.app.ui.theme.SurfaceHigh
import com.dpireborn.app.ui.theme.TextSecondary

/** Escolha de como adicionar PKG: seletor oficial do Android, navegador do app ou importar um arquivo. */
@Composable
fun FolderChoiceDialog(
    onTree: () -> Unit,
    onBrowser: () -> Unit,
    onDocument: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Adicionar PKG") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ChoiceCard(
                    Icons.Filled.FolderOpen, "Pasta pelo seletor do Android",
                    "Você escolhe a pasta e autoriza só ela. O Android 11 em diante não deixa escolher a pasta Download nem a raiz do armazenamento.",
                    onTree,
                )
                ChoiceCard(
                    Icons.Filled.Folder, "Navegador de pastas do app",
                    "Mostra todas as pastas, inclusive Download. Exige a permissão \"Acesso a todos os arquivos\".",
                    onBrowser,
                )
                ChoiceCard(
                    Icons.Filled.FileUpload, "Importar um PKG",
                    "Escolhe um único arquivo .pkg pelo seletor do Android.",
                    onDocument,
                )
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

@Composable
private fun ChoiceCard(icon: ImageVector, title: String, text: String, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceHigh),
        border = BorderStroke(1.dp, OutlineDim),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
            Column(modifier = Modifier.padding(start = 12.dp)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(text, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
        }
    }
}
