package com.dpireborn.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dpireborn.app.AppViewModel
import com.dpireborn.app.catalog.CatalogEntry
import com.dpireborn.app.catalog.CatalogViewModel
import com.dpireborn.app.data.methodLabel
import com.dpireborn.app.ps4.YtAdblockViewModel
import com.dpireborn.app.ps4.YtState
import com.dpireborn.app.ui.theme.DangerRed
import com.dpireborn.app.ui.theme.SuccessGreen
import com.dpireborn.app.ui.theme.TextSecondary
import com.dpireborn.app.ui.theme.WarnAmber

/** Área exclusiva do YouTube (PS4): informações + menu de opções, com o módulo de AdBlocker. */
@Composable
fun YoutubeScreen(e: CatalogEntry, cvm: CatalogViewModel, vm: AppViewModel, yt: YtAdblockViewModel) {
    val consoles by vm.consoles.collectAsStateWithLifecycle()
    val selId by vm.selectedConsoleId.collectAsStateWithLifecycle()
    val running by yt.running.collectAsStateWithLifecycle()
    val log by yt.log.collectAsStateWithLifecycle()
    val state by yt.state.collectAsStateWithLifecycle()
    val summary by yt.summary.collectAsStateWithLifecycle()
    val console = consoles.firstOrNull { it.id == selId }
    var port by rememberSaveable { mutableStateOf("2121") }
    var force by rememberSaveable { mutableStateOf(false) }
    var showPanel by rememberSaveable { mutableStateOf(false) }
    val portNum = port.toIntOrNull()
    val canRun = console != null && portNum != null && portNum in 1..65535 && !running

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        DetailHeader(e, cvm)
        Spacer(Modifier.height(14.dp))
        DetailInfo(e)
        Spacer(Modifier.height(12.dp))

        SectionCard {
            Text("Opções do YouTube", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            ) {
                Icon(Icons.Filled.Block, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text("Adicionar AdBlocker ao YouTube", fontWeight = FontWeight.SemiBold)
                    Text("Plugin yt_adblock.prx (AdBlocker + SponsorBlock) para o GoldHEN", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
                FilledTonalButton(onClick = { showPanel = !showPanel }) { Text(if (showPanel) "Fechar" else "Abrir") }
            }
        }

        if (showPanel) {
            Spacer(Modifier.height(12.dp))
            SectionCard {
                Text("AdBlocker", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                if (console == null) {
                    Text(
                        "Cadastre e selecione um console em Início → Console antes de continuar.",
                        color = WarnAmber, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 6.dp),
                    )
                } else {
                    Text(
                        "PS4: ${console.name} • ${console.ip} • ${methodLabel(console.method)}",
                        style = MaterialTheme.typography.bodySmall, color = TextSecondary, modifier = Modifier.padding(top = 6.dp),
                    )
                }
                OutlinedTextField(
                    value = port, onValueChange = { port = it.filter { c -> c.isDigit() }.take(5) }, singleLine = true,
                    label = { Text("Porta do FTP do GoldHEN") }, colors = fieldColors(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                )
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                    Checkbox(checked = force, onCheckedChange = { force = it })
                    Text("Já tenho o YouTube instalado (continuar mesmo que o app não seja encontrado)", style = MaterialTheme.typography.bodySmall)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                    Button(onClick = { console?.let { yt.install(it.ip, portNum ?: 2121, force) } }, enabled = canRun) { Text("Adicionar AdBlocker") }
                    OutlinedButton(onClick = { console?.let { yt.check(it.ip, portNum ?: 2121, force) } }, enabled = canRun) { Text("Verificar configuração") }
                }
                if (running) LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 10.dp))

                if (state != YtState.UNKNOWN || running) {
                    Row(verticalAlignment = Alignment.Top, modifier = Modifier.padding(top = 10.dp)) {
                        when (state) {
                            YtState.OK -> Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = SuccessGreen)
                            YtState.ERROR -> Icon(Icons.Filled.Error, contentDescription = null, tint = DangerRed)
                            else -> {}
                        }
                        Text(
                            "  $summary",
                            color = when (state) { YtState.OK -> SuccessGreen; YtState.ERROR -> DangerRed; else -> TextSecondary },
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
                log.forEach { Text(it, style = MaterialTheme.typography.bodySmall, color = TextSecondary, modifier = Modifier.padding(top = 2.dp)) }
            }
        }

        Spacer(Modifier.height(12.dp))
        ExternalSourceWarning(
            "Antes de usar: (1) o plugin e o plugins.ini são os arquivos que você forneceu; o DPI Reborn não os escreveu nem os auditou por completo. " +
                "Pelas strings do arquivo, ele usa rede, hooks no app do YouTube e consulta o serviço SponsorBlock (sponsor.ajay.app), enviando IDs de vídeo. " +
                "(2) A instalação usa o FTP do GoldHEN (porta 2121 é o padrão citado pelo DirectPackageInstaller; não foi testada aqui) e procura o YouTube em " +
                "/user/app/CUSA01015 (caminho não verificado). (3) Exige GoldHEN 2.3 ou mais novo com o carregamento de plugins ligado no menu do GoldHEN. " +
                "Nada é apagado: o app só acrescenta a entrada ao plugins.ini e faz backup do que for trocar.",
        )
        Spacer(Modifier.height(24.dp))
    }
}
