package com.dpireborn.app.ps4

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dpireborn.app.util.CrashLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class YtState { UNKNOWN, OK, NOT_CONFIGURED, ERROR }

private class YtFail(msg: String) : Exception(msg)

/**
 * Instala/verifica o plugin yt_adblock.prx do GoldHEN no PS4 pelo servidor FTP do GoldHEN.
 * Os dois arquivos (plugin e plugins.ini) vêm do usuário e ficam em assets/ytadblock; nada aqui é inventado.
 * Regras: nunca apaga nem sobrescreve às cegas, faz backup do que for trocar, não duplica entradas e não mexe
 * em outros plugins nem em seções desconhecidas do plugins.ini.
 */
class YtAdblockViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext

    val running = MutableStateFlow(false)
    val log = MutableStateFlow<List<String>>(emptyList())
    val state = MutableStateFlow(YtState.UNKNOWN)
    val summary = MutableStateFlow("Ainda não verificado")

    companion object {
        const val YOUTUBE_APP_DIR = "/user/app/CUSA01015"
        const val GOLDHEN_DIR = "/data/GoldHEN"
        const val PLUGINS_DIR = "/data/GoldHEN/plugins"
        const val INI_PATH = "/data/GoldHEN/plugins.ini"
        const val PRX_NAME = "yt_adblock.prx"
    }

    private fun step(msg: String) {
        log.value = log.value + msg
    }

    fun check(ip: String, port: Int, force: Boolean) = run(ip, port, false, force)
    fun install(ip: String, port: Int, force: Boolean) = run(ip, port, true, force)

    private fun run(ip: String, port: Int, install: Boolean, force: Boolean) {
        if (running.value) return
        running.value = true
        log.value = emptyList()
        state.value = YtState.UNKNOWN
        summary.value = if (install) "Instalando…" else "Verificando…"
        viewModelScope.launch(Dispatchers.IO) {
            try {
                work(ip, port, install, force)
            } catch (e: YtFail) {
                step("✗ ${e.message}")
                state.value = YtState.ERROR
                summary.value = e.message ?: "Erro"
            } catch (e: Exception) {
                CrashLog.log("youtube-adblock", "falha na operação FTP", e)
                step("✗ ${e.message ?: e.javaClass.simpleName}")
                state.value = YtState.ERROR
                summary.value = "Falha de comunicação com o PS4: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                running.value = false
            }
        }
    }

    private fun asset(name: String): ByteArray = ctx.assets.open("ytadblock/$name").use { it.readBytes() }

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())

    private fun work(ip: String, port: Int, install: Boolean, force: Boolean) {
        val prx = asset(PRX_NAME)
        val wanted = parseIni(String(asset("plugins.ini"), Charsets.ISO_8859_1))
        if (wanted.isEmpty()) throw YtFail("O plugins.ini fornecido não tem nenhuma entrada válida")

        step("Conectando ao FTP do PS4 em $ip:$port…")
        FtpClient(ip, port).use { ftp ->
            ftp.connect()
            ftp.login()
            step("✓ Conectado")

            val ytOk = ftp.dirExists(YOUTUBE_APP_DIR)
            if (ytOk) {
                step("✓ YouTube (CUSA01015) encontrado no PS4")
            } else if (!force) {
                state.value = YtState.NOT_CONFIGURED
                throw YtFail(
                    "YouTube (CUSA01015) não encontrado em $YOUTUBE_APP_DIR. Instale o YouTube no PS4 antes de usar o AdBlocker. " +
                        "Se ele está instalado e este caminho não vale no seu firmware, marque \"Já tenho o YouTube\" e tente de novo."
                )
            } else {
                step("! YouTube não confirmado; seguindo porque você marcou que ele está instalado")
            }

            if (!ftp.dirExists(GOLDHEN_DIR)) {
                throw YtFail("Pasta $GOLDHEN_DIR não encontrada. Abra o GoldHEN no PS4 ao menos uma vez e confira a porta do FTP.")
            }
            step("✓ Pasta $GOLDHEN_DIR existe")

            val plugDirOk = ftp.dirExists(PLUGINS_DIR)
            val remotePrx = if (plugDirOk) ftp.retr("$PLUGINS_DIR/$PRX_NAME") else null
            val prxSame = remotePrx != null && remotePrx.contentEquals(prx)
            step(
                when {
                    !plugDirOk -> "• Pasta de plugins ainda não existe"
                    remotePrx == null -> "• Plugin ainda não está no PS4"
                    prxSame -> "✓ Plugin já está no PS4 (idêntico ao fornecido)"
                    else -> "! Já existe um $PRX_NAME diferente no PS4"
                }
            )
            val iniBytes = ftp.retr(INI_PATH)
            val iniText = iniBytes?.let { String(it, Charsets.ISO_8859_1) }
            var merged = iniText
            var iniChanged = false
            for ((section, lines) in wanted) {
                val r = mergeIni(merged, section, lines)
                merged = r.first
                iniChanged = iniChanged || r.second
            }
            step(if (iniChanged) "• plugins.ini precisa ser atualizado" else "✓ plugins.ini já contém a entrada")

            if (!install) {
                if (prxSame && !iniChanged) {
                    state.value = YtState.OK
                    summary.value = "AdBlocker configurado"
                } else {
                    state.value = YtState.NOT_CONFIGURED
                    summary.value = "AdBlocker não está totalmente configurado"
                }
                return
            }

            // ---- instalação ----
            if (!plugDirOk) {
                step("Criando $PLUGINS_DIR…")
                if (!ftp.mkdir(PLUGINS_DIR)) throw YtFail("Não foi possível criar $PLUGINS_DIR")
            }
            if (!prxSame) {
                if (remotePrx != null) {
                    val bak = "$PLUGINS_DIR/$PRX_NAME.bak-${stamp()}"
                    step("Backup do plugin existente em $bak…")
                    ftp.stor(bak, remotePrx)
                }
                step("Enviando $PRX_NAME (${prx.size} bytes)…")
                ftp.stor("$PLUGINS_DIR/$PRX_NAME", prx)
                val sz = ftp.size("$PLUGINS_DIR/$PRX_NAME")
                if (sz != null && sz != prx.size.toLong()) throw YtFail("O tamanho no PS4 ($sz) difere do enviado (${prx.size})")
                step("✓ Plugin enviado")
            }
            if (iniChanged) {
                if (iniBytes != null) {
                    val bak = "$INI_PATH.bak-${stamp()}"
                    step("Backup do plugins.ini em $bak…")
                    ftp.stor(bak, iniBytes)
                }
                step("Atualizando plugins.ini (só acrescenta a entrada)…")
                ftp.stor(INI_PATH, (merged ?: "").toByteArray(Charsets.ISO_8859_1))
            }

            // ---- verificação final ----
            val afterPrx = ftp.retr("$PLUGINS_DIR/$PRX_NAME")
            val afterIni = ftp.retr(INI_PATH)?.let { String(it, Charsets.ISO_8859_1) }
            var iniOk = afterIni != null
            for ((section, lines) in wanted) if (afterIni == null || mergeIni(afterIni, section, lines).second) iniOk = false
            if (afterPrx != null && afterPrx.contentEquals(prx) && iniOk) {
                step("✓ Verificação final concluída")
                state.value = YtState.OK
                summary.value = "AdBlocker instalado. Reinicie o YouTube. No GoldHEN, o carregamento de plugins precisa estar ligado."
            } else {
                throw YtFail("A verificação final não confirmou a instalação. Rode \"Verificar configuração\".")
            }
        }
    }

    /** Lê um plugins.ini: seção -> linhas de caminho (ignora vazias e comentários com ;). */
    private fun parseIni(text: String): LinkedHashMap<String, List<String>> {
        val out = LinkedHashMap<String, MutableList<String>>()
        var cur: String? = null
        for (raw in text.split("\n")) {
            val l = raw.trim()
            if (l.isEmpty() || l.startsWith(";")) continue
            if (l.startsWith("[") && l.endsWith("]")) {
                cur = l.substring(1, l.length - 1).trim()
                out.getOrPut(cur) { ArrayList() }
            } else if (cur != null) {
                out.getOrPut(cur) { ArrayList() }.add(l)
            }
        }
        return LinkedHashMap(out.filterValues { it.isNotEmpty() })
    }

    /**
     * Acrescenta [lines] à seção [section] sem apagar nem reordenar nada. Devolve o texto novo e se houve mudança.
     * Mantém o estilo de quebra de linha do arquivo existente (CRLF ou LF).
     */
    private fun mergeIni(existing: String?, section: String, lines: List<String>): Pair<String, Boolean> {
        val nl = if (existing != null && existing.contains("\r\n")) "\r\n" else "\n"
        if (existing == null || existing.isBlank()) {
            return ("[" + section + "]" + nl + lines.joinToString(nl) + nl) to true
        }
        val parts = existing.split("\n").toMutableList() // mantém o \r no fim de cada linha
        var header = -1
        for (i in parts.indices) {
            if (parts[i].trim().equals("[$section]", ignoreCase = true)) {
                header = i
                break
            }
        }
        if (header < 0) {
            val sb = StringBuilder(existing)
            if (!existing.endsWith("\n")) sb.append(nl)
            sb.append(nl).append("[").append(section).append("]").append(nl)
            for (l in lines) sb.append(l).append(nl)
            return sb.toString() to true
        }
        var end = parts.size
        for (i in header + 1 until parts.size) {
            if (parts[i].trim().startsWith("[")) {
                end = i
                break
            }
        }
        val present = parts.subList(header + 1, end).map { it.trim() }.toSet()
        val missing = lines.filter { it !in present }
        if (missing.isEmpty()) return existing to false
        var insertAt = header + 1
        for (i in header + 1 until end) if (parts[i].trim().isNotEmpty()) insertAt = i + 1
        val cr = if (nl == "\r\n") "\r" else ""
        parts.addAll(insertAt, missing.map { it + cr })
        return parts.joinToString("\n") to true
    }
}
